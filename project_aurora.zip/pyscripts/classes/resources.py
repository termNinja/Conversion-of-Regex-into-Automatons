import re, os
# -----------------------------------------------------------------------------
class Edge:
    def __init__(self, end_node, weight):
        self.end_node = end_node
        self.weight = weight

    def __str__(self):
        return "(" + str(self.end_node) + ", " + str(self.weight) + ")"
# -----------------------------------------------------------------------------
# *****************************************************************************
# -----------------------------------------------------------------------------
class Node:
    def __init__(self, node_val, is_ending):
        self.node_val = node_val
        self.is_ending = is_ending

    def __str__(self):
        if self.is_ending:
            return "(" + str(self.node_val) + ")"
        else:
            return str(self.node_val)
# -----------------------------------------------------------------------------
# *****************************************************************************
# -----------------------------------------------------------------------------
# When reading thomhpson's graph from .gv file, we KNOW that
# node 1 is ENDING state. Cast it into such by YOURSELF.
class Graph:
    def __init__(self, graph_map, graph_name):
        self.graph_map = {}
        self.graph_name = graph_name

    def __str__(self):
        output = str(self.graph_name) + "\n-----------------------------\n"
        output += str(self.graph_map)
        return output

    def form_graph_from_gv(self):
        f = open("../graphs/" + self.graph_name, "r")
        data = f.read()
        f.close()
        print data


        # -----------------------------------------------------------------------------------------
        # Searching for ending nodes
        # TODO add regex to fill this array properly
        ending_nodes = []
        ending_nodes.append(1)

        # -----------------------------------------------------------------------------------------
        # -----------------------------------------------------------------------------------------
        # Forming graph
        regex = r"\"([a-zA-Z0-9]+)\"\s*->\s*\"([a-zA-Z0-9]+)\"\s*"
        regex += r"(\[label\s*[=]\s*\"([a-zA-Z0-9]+)\"\])?"
        regex = re.compile(regex)
        for iter in regex.finditer(data):
            # print iter.group(1), iter.group(2), iter.group(4)
            node_val = iter.group(1)
            into_node = iter.group(2)
            if iter.group(4) == None:
                graph_weight = "eps"
            else:
                graph_weight = iter.group(4)

            # Creating node
            if node_val in ending_nodes:
                node = Node(node_val, True)
            else:
                node = Node(node_val, False)

            # Creating edge
            edge = Edge(into_node, graph_weight)

            ## TODO: Form graph from parsed data...
            ## TODO Fix this baboon later...damn dictionaries
            print node, edge
#            self.graph_map.append(node.node_val : edge)

        # -----------------------------------------------------------------------------------------

    def export_as_gv():
        return 1

    # Export graph strcutre as pdf
    # command is:
    # dot -Tpdf ../../graphs/source_file.gv -o ../../graphs/output.pdf
    def export_as_pdf():
        # os.system("...")
        return 1

    def elim_eps():
        return 1

    def determinize():
        return 1

    def minimize():
        return 1
# -----------------------------------------------------------------------------
